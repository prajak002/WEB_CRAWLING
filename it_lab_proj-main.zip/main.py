import crawler
import converter

if __name__ == "__main__" :
    crawler.crawl()
    converter.convert()